@echo off
REM Double-click to process your statements into the review sheet.
cd /d "%~dp0"
python pdf2sheets.py
echo.
pause
