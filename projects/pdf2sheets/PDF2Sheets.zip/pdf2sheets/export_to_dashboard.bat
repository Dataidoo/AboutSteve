@echo off
REM Double-click AFTER you've finished the review sheet (incl. Name2 polish).
REM Writes Dashboard_Export.xlsx for your dashboard.
cd /d "%~dp0"
python pdf2sheets.py --export
echo.
pause
