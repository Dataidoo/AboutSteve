#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║         PDF2Sheets  v3.0                 ║
║         All PDFs (across year folders) → one review sheet     ║
╚══════════════════════════════════════════════════════════════╝

SETUP (run once):
    pip install pdfplumber pandas openpyxl

USAGE:
    python pdf2sheets.py                  (asks for the folder)
    python pdf2sheets.py --export         (send finished list to dashboard)

THE REVIEW SHEET — PDF2Sheets_Review.xlsx — columns:
    Date | Name1 | Name2 | Main | Sub | Amount | Raw
      Name1  clean merchant name        (remembered, carries across all years)
      Name2  fresh raw each run → reduce to LOCATION before export (NOT remembered)
      Main   primary category dropdown   (remembered)
      Sub    independent breakdown drop  (remembered)
      Amount from the statement          Raw  untouched bank string (never changes)

HOW MEMORY WORKS:
    You label rows right in the review sheet. On the next run the parser reads
    those labels back and stores them in merchant_list.txt, keyed on the bank
    string. That list is your memory — label a merchant once and every matching
    transaction, this year and every future year, is filled in automatically.
    You normally never open merchant_list.txt by hand.

MOVING TO THE DASHBOARD:
    Reduce Name2 to the location, then run  export_to_dashboard.bat  (or
    python pdf2sheets.py --export). It writes Dashboard_Export.xlsx
    shaped for DalaDash: Date / Main / Description(Name1) / Amount / Sub /
    Location(Name2), with data from row 3.

OUTPUT (in the statements folder):
    PDF2Sheets_Review.xlsx   — your one review file (rebuilt & grown each run)
    merchant_list.txt        — your merchant memory (carries year to year)
    merchant_reference.md     — readable merchant list grouped by Main
    Dashboard_Export.xlsx    — written only when you run --export
"""

import re
import sys
import argparse
from pathlib import Path
from datetime import datetime
from collections import defaultdict

# ── Dependency check ───────────────────────────────────────────────────────────
MISSING = []
try:
    import pdfplumber
except ImportError:
    MISSING.append("pdfplumber")
try:
    import pandas as pd
except ImportError:
    MISSING.append("pandas")
try:
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.worksheet.table import Table, TableStyleInfo
    from openpyxl.formatting.rule import FormulaRule
except ImportError:
    MISSING.append("openpyxl")

if MISSING:
    print(f"\n❌  Missing packages: {', '.join(MISSING)}")
    print(f"    Run this first:  pip install {' '.join(MISSING)}\n")
    sys.exit(1)

# ══════════════════════════════════════════════════════════════════════════════
#  YOUR MERCHANT LIST  —  merchant_list.txt
#  One line per merchant. This is the memory that carries across every file and
#  every year — label a merchant once and it stays labelled forever.
# ══════════════════════════════════════════════════════════════════════════════

_EDITS_PATH = Path(__file__).parent / "merchant_list.txt"

# Main sorting categories (the primary system).
MAIN_CATEGORIES = ["Rent", "Food", "Kids", "Phone", "Travel",
                   "Vice", "Shop", "Subs", "Xtra"]

# Sub categories — an independent breakdown, NOT tied to the mains.
SUB_CATEGORIES = ["Home", "Work", "Out", "Fast", "Groc", "Conv", "Gas",
                  "Coftuk", "Util", "Bill", "Service", "Puffs", "Booze",
                  "Smokes", "Drugs", "Hair", "Gear", "Pets", "Bus", "Uber",
                  "Train", "Owed", "Loan", "Gov", "Anina", "Kids", "Toys"]

DEFAULT_EDITS = """# merchant_list.txt  —  your merchant memory (carries across all years)
# ---------------------------------------------------------------------------
# One merchant per line. The | character (pipe key, above Enter) splits fields:
#
#     exact bank text | Name1 | Main | Sub
#
#   exact bank text — type it as the bank prints it (case/spacing don't matter)
#   Name1          — the clean merchant name you want to see
#   Main           — one of: Rent Food Kids Phone Travel Vice Shop Subs Xtra
#   Sub            — one of: Home Work Out Fast Groc Conv Gas Coftuk Util Bill
#                    Service Puffs Booze Smokes Drugs Hair Gear Pets Bus Uber
#                    Train Owed Loan Gov Anina Kids Toys
#
# You normally never edit this by hand — it fills itself in from the labels you
# type in the review sheet. Lines starting with # are ignored.
# ---------------------------------------------------------------------------

# --- examples — edit or delete, then add your own ---
TIMHORTONS | Tims    | Food | Fast
NETFLIX    | Netflix | Subs | Bill
"""


def _norm(s) -> str:
    """Normalize for matching: uppercase, all whitespace removed. Robust to PDF
    spacing quirks, but still an exact (non-fuzzy, non-synonym) match."""
    return re.sub(r"\s+", "", str(s)).upper()


def load_edits():
    """
    Read merchant_list.txt. Returns:
      rules = list of {match_raw, match_norm, name1, main, sub}
      cats  = (main_list, sub_list) for the dropdowns
    """
    if not _EDITS_PATH.exists():
        _EDITS_PATH.write_text(DEFAULT_EDITS, encoding="utf-8")
        print(f"  ·  Created {_EDITS_PATH.name} — your merchant memory.")

    rules = []
    extra_mains, extra_subs = [], []
    for raw in _EDITS_PATH.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = [p.strip() for p in line.split("|")]
        if len(parts) < 2 or not parts[0]:
            continue  # need at least: bank text | Name1
        match_raw = parts[0]
        name1 = parts[1] if len(parts) > 1 and parts[1] else parts[0]
        main  = parts[2] if len(parts) > 2 and parts[2] else "unknown"
        sub   = parts[3] if len(parts) > 3 and parts[3] else ""

        rules.append({"match_raw": match_raw, "match_norm": _norm(match_raw),
                      "name1": name1, "main": main, "sub": sub})
        if main not in MAIN_CATEGORIES and main != "unknown" and main not in extra_mains:
            extra_mains.append(main)
        if sub and sub not in SUB_CATEGORIES and sub not in extra_subs:
            extra_subs.append(sub)

    mains = MAIN_CATEGORIES + extra_mains + ["unknown"]
    subs  = SUB_CATEGORIES + extra_subs
    if rules:
        print(f"  loaded {len(rules)} merchant(s) from {_EDITS_PATH.name}")
    return rules, (mains, subs)


_RULES, ALL_CATEGORIES = load_edits()


def match_transaction(raw: str):
    """Match raw bank text against the merchant list. Longest (most specific)
    match wins. Returns (name1, main, sub) or (None, None, None) if no match."""
    raw_norm = _norm(raw)
    best = None
    for rule in _RULES:
        if rule["match_norm"] and rule["match_norm"] in raw_norm:
            if best is None or len(rule["match_norm"]) > len(best["match_norm"]):
                best = rule
    if best is None:
        return None, None, None
    return best["name1"], best["main"], best["sub"]


# ══════════════════════════════════════════════════════════════════════════════
#  LEARNING FROM THE REVIEW SHEET
#  You label rows in the Excel; this reads those edits back and remembers them.
#  Keyed on the raw bank text (stable across runs) — no fragile date/amount keys,
#  no invented data, so it can't rot the way the old REVIEW_ME setup did.
# ══════════════════════════════════════════════════════════════════════════════

AUTO_MARKER = "# === auto-learned from the review sheet — safe to leave alone ==="


def reload_edits():
    """Re-read merchant_list.txt into the module globals."""
    global _RULES, ALL_CATEGORIES
    _RULES, ALL_CATEGORIES = load_edits()


def _split_edits_text():
    """Split the merchant list into (hand-written head, auto-learned dict).
    auto dict: _norm(match) -> (match, name1, main, sub)."""
    if not _EDITS_PATH.exists():
        return "", {}
    text = _EDITS_PATH.read_text(encoding="utf-8")
    head, _, tail = text.partition(AUTO_MARKER)
    auto = {}
    for raw in tail.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = [p.strip() for p in line.split("|")]
        if len(parts) < 2 or not parts[0]:
            continue
        match = parts[0]
        name1 = parts[1] or parts[0]
        main  = parts[2] if len(parts) > 2 and parts[2] else "unknown"
        sub   = parts[3] if len(parts) > 3 and parts[3] else ""
        auto[_norm(match)] = (match, name1, main, sub)
    return head, auto


def _write_edits(head, auto):
    """Rewrite the merchant list: untouched head + regenerated auto section."""
    out = [head.rstrip("\n"), "", AUTO_MARKER,
           "# Filled in from the labels you type in the review sheet. You can edit",
           "# by hand too — e.g. shorten a match so one line catches every branch.", ""]
    for _, (match, name1, main, sub) in sorted(auto.items(), key=lambda kv: kv[1][1].lower()):
        line = f"{match} | {name1} | {main}" + (f" | {sub}" if sub else "")
        out.append(line)
    _EDITS_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")


def harvest_review(review_path: Path):
    """Read the user's labels from the existing review sheet. Returns a list of
    (raw, name1, main, sub) for rows whose Name1/Main/Sub differ from what the
    current merchant list produces — i.e. things the user assigned by hand.
    Keyed on the Raw column (the untouched bank string), which is stable."""
    if not review_path.exists():
        return []
    try:
        from openpyxl import load_workbook
        wb = load_workbook(review_path, data_only=True)
        ws = wb["Transactions"] if "Transactions" in wb.sheetnames else wb.active
        hdr = {str(ws.cell(1, c).value).strip().lower(): c
               for c in range(1, ws.max_column + 1)}
        cRaw  = hdr.get("raw")            # untouched bank string = the match key
        cName = hdr.get("name1")
        cMain = hdr.get("main")
        cSub  = hdr.get("sub")
        if not cRaw:                      # fall back to Name2 if Raw missing
            cRaw = hdr.get("name2")
        edits = []
        for r in range(2, ws.max_row + 1):
            raw = ws.cell(r, cRaw).value if cRaw else None
            if not raw:
                continue
            raw   = str(raw).strip()
            name1 = str(ws.cell(r, cName).value or "").strip() if cName else ""
            main  = str(ws.cell(r, cMain).value or "").strip() if cMain else ""
            sub   = str(ws.cell(r, cSub).value or "").strip()  if cSub  else ""

            curN, curM, curS = match_transaction(raw)
            curN = curN if curN is not None else raw
            curM = curM if curM is not None else "unknown"
            curS = curS if curS is not None else ""

            uName = name1 if name1 else curN
            uMain = main  if main  else curM
            uSub  = sub   if sub   else curS
            meaningful = (uName != raw) or (uMain.lower() != "unknown") or bool(uSub)
            if meaningful and (uName, uMain, uSub) != (curN, curM, curS):
                edits.append((raw, uName, uMain if uMain else "unknown", uSub))
        wb.close()
        return edits
    except Exception as e:
        print(f"  ⚠  Could not read prior review edits: {e}")
        return []


def learn_from_review(review_path: Path) -> int:
    """Harvest labels from the review sheet, fold them into the merchant list,
    and reload. Returns how many merchants were learned/updated."""
    harvested = harvest_review(review_path)
    if not harvested:
        return 0
    head, auto = _split_edits_text()
    for raw, name1, main, sub in harvested:
        auto[_norm(raw)] = (raw, name1, main, sub)
    _write_edits(head, auto)
    reload_edits()
    return len(harvested)


# ══════════════════════════════════════════════════════════════════════════════
#  PDF PARSING   (unchanged core — this part already works for your statements)
# ══════════════════════════════════════════════════════════════════════════════

MONTHS = {'Jan':1,'Feb':2,'Mar':3,'Apr':4,'May':5,'Jun':6,
          'Jul':7,'Aug':8,'Sep':9,'Oct':10,'Nov':11,'Dec':12}

SKIP_RE = re.compile(
    r'continuedonnextpage|continued on next page|'
    r"here.s what happened|here.swhat|"
    r'[Pp]age\s*\d+\s*of\s*\d+|Page\d+of\d+|'
    r'Amounts\s*Amounts|DateTransactions|withdrawn|deposited|'
    r'Minustotal|Plustotal|minus total|plus total|'
    r'YourPreferredPackage|your preferred package|'
    r'Day-to-DayBanking|day-to-day banking|scotiabank|'
    r'MRSTEVENBONNAR|MR\.?\s*STEVEN|'
    r'^\s*[Dd]ate\s+[Tt]ransactions|'
    r'Youraccountnumber|your account number|'
    r'Call1800|call 1 800|www\.scotiabank|Foronline|for online|'
    r'^\d{5}\s|^\d{6}\s|^\*\d+\*$|^[-|]+$|^\d{2,3}$',
    re.I
)

TX_RE = re.compile(
    r'^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(\d{1,2})\s+(.*)'
)

TRAIL_RE = re.compile(
    r'\s+(-?[\d,]+\.\d{2})\s+(-?[\d,]+\.\d{2})\s*$'
    r'|\s+(-?[\d,]+\.\d{2})\s*$'
)

FULL_MONTHS = {
    'january':1,'february':2,'march':3,'april':4,'may':5,'june':6,
    'july':7,'august':8,'september':9,'october':10,'november':11,'december':12
}

PERIOD_RE = re.compile(
    r'(January|February|March|April|May|June|July|August|September|October|November|December)'
    r'\s*(\d{1,2}),?\s*(?:(\d{4})\s*)?to\s*'
    r'(January|February|March|April|May|June|July|August|September|October|November|December)'
    r'\s*(\d{1,2}),?\s*(\d{4})',
    re.I
)


def resolve_year(month_num, start_month, start_year, end_month, end_year):
    if start_year == end_year:
        return start_year
    if month_num >= start_month:
        return start_year
    return end_year


def year_month_from_path(path: Path):
    """Best-effort (year, month) from the file PATH — the file name first, then
    its parent folder (you keep month PDFs inside year folders, e.g.
    ...\\Bank Statements\\2020\\statement-2020-06.pdf). Used only when the PDF's
    own statement period can't be parsed. Returns (year|None, month|None)."""
    stem = path.stem
    year = month = None
    ym = re.search(r'(19|20)\d{2}', stem)
    if ym:
        year = int(ym.group(0))
    # month as a name (June, Jun, ...)
    for name, num in {**MONTHS, **{k.title(): v for k, v in FULL_MONTHS.items()}}.items():
        if re.search(rf'\b{name}', stem, re.I):
            month = num
            break
    # month as a zero-padded number (statement-2020-06)
    if month is None:
        m = re.search(r'(?:^|[^\d])(0[1-9]|1[0-2])(?:[^\d]|$)', stem)
        if m:
            month = int(m.group(1))
    # year from the parent folder name if the file name didn't carry one
    if year is None:
        pm = re.search(r'(19|20)\d{2}', path.parent.name)
        if pm:
            year = int(pm.group(0))
    return year, month


def parse_pdf(pdf_path: Path) -> list[dict]:
    """Extract all transactions from one bank-statement PDF."""
    transactions = []
    file_year, file_month = year_month_from_path(pdf_path)

    with pdfplumber.open(str(pdf_path)) as pdf:
        all_lines = []
        for page in pdf.pages:
            text = page.extract_text(x_tolerance=3, y_tolerance=3) or ""
            for line in text.split('\n'):
                all_lines.append(line.rstrip())

        # ── Statement period — real years only, never invented ──
        start_month = start_year = end_month = end_year = None
        period_found = False
        stmt_period = "Unknown Period"
        for line in all_lines[:60]:
            m = PERIOD_RE.search(line)
            if m:
                sm = FULL_MONTHS.get(m.group(1).lower(), 1)
                sy = int(m.group(3)) if m.group(3) else int(m.group(6))
                em = FULL_MONTHS.get(m.group(4).lower(), 1)
                ey = int(m.group(6))
                start_month, start_year = sm, sy
                end_month, end_year     = em, ey
                period_found = True
                s_name = datetime(sy, sm, 1).strftime('%b %Y')
                e_name = datetime(ey, em, 1).strftime('%b %Y')
                stmt_period = s_name if s_name == e_name else f"{s_name} – {e_name}"
                break
        if not period_found and file_year:
            if file_month:
                stmt_period = datetime(file_year, file_month, 1).strftime('%b %Y') + " (from filename)"
            else:
                stmt_period = f"{file_year} (from filename)"

        prev_balance = None
        i = 0
        while i < len(all_lines):
            raw = all_lines[i]
            if SKIP_RE.search(raw) or not raw.strip():
                i += 1
                continue
            m = TX_RE.match(raw.strip())
            if not m:
                i += 1
                continue

            mon_str, day_str, rest = m.group(1), m.group(2), m.group(3)
            month_num = MONTHS[mon_str]
            day       = int(day_str)

            # Date: real date only when we know the year (period, else filename).
            # Never invent a year — fall back to the raw "Jun 27" string.
            year = None
            if period_found:
                year = resolve_year(month_num, start_month, start_year, end_month, end_year)
            elif file_year:
                year = file_year
            if year:
                try:
                    date = datetime(year, month_num, day).date()
                except ValueError:
                    i += 1
                    continue
            else:
                date = f"{mon_str} {day}"

            t = TRAIL_RE.search(rest)
            if not t:
                i += 1
                continue
            if t.group(1) and t.group(2):
                raw_amt_str = t.group(1)
                balance_str = t.group(2)
            elif t.group(3):
                raw_amt_str = None
                balance_str = t.group(3)
            else:
                i += 1
                continue

            balance = float(balance_str.replace(',', '').replace('$', ''))
            desc = TRAIL_RE.sub('', rest).strip()

            if re.search(r'opening.?balance|closing.?balance', desc, re.I):
                prev_balance = balance
                i += 1
                continue

            # AMOUNT: use the PRINTED figure; balance change only sets the sign.
            balance_change = round(balance - prev_balance, 2) if prev_balance is not None else None
            if raw_amt_str is not None:
                magnitude = abs(float(raw_amt_str.replace(',', '')))
                if balance_change is not None and balance_change < 0:
                    amount = -magnitude
                elif balance_change is not None and balance_change > 0:
                    amount = magnitude
                else:
                    amount = magnitude
            elif balance_change is not None:
                amount = balance_change
            else:
                amount = 0.0

            # merchant detail line (the next non-furniture line)
            merchant_raw = ""
            j = i + 1
            while j < len(all_lines):
                next_raw = all_lines[j].strip()
                if not next_raw or SKIP_RE.search(next_raw) or TX_RE.match(next_raw):
                    break
                merchant_raw = next_raw
                j += 1
                break

            full_raw = f"{desc} {merchant_raw}".strip()
            transactions.append({
                'stmt_period':  stmt_period,
                'date':         date,
                'full_raw':     full_raw,
                'amount':       round(amount, 2),
                'balance':      balance,
            })
            prev_balance = balance
            i = j if merchant_raw else i + 1

    return transactions


# ══════════════════════════════════════════════════════════════════════════════
#  ETRANSFER HISTORY  (optional helper — names the person on an e-transfer)
# ══════════════════════════════════════════════════════════════════════════════

ETRANSFER_RE = re.compile(r'e.transfer|etransfer|free interac|emailmoneytrf|mb.email', re.I)


def load_etransfer_history(path: Path) -> list[dict]:
    suffix = path.suffix.lower()
    try:
        if suffix == '.csv':
            df = pd.read_csv(path)
        elif suffix in ('.xlsx', '.xls'):
            df = pd.read_excel(path)
        else:
            print(f"  ⚠  Unsupported eTransfer file format: {suffix}")
            return []
    except Exception as e:
        print(f"  ⚠  Could not load eTransfer history: {e}")
        return []

    df.columns = [c.strip().lower() for c in df.columns]
    date_col = next((c for c in df.columns if 'date' in c), None)
    amt_col  = next((c for c in df.columns if 'amount' in c or 'amt' in c), None)
    name_col = next((c for c in df.columns
                     if any(k in c for k in ('name','recipient','sender','payee','contact'))), None)
    if not all([date_col, amt_col, name_col]):
        print(f"  ⚠  eTransfer columns not recognized. Found: {list(df.columns)}")
        return []

    records = []
    for _, row in df.iterrows():
        try:
            d  = pd.to_datetime(row[date_col]).date()
            a  = abs(float(str(row[amt_col]).replace('$','').replace(',','')))
            nm = str(row[name_col]).strip()
            records.append({'date': d, 'amount': a, 'name': nm})
        except Exception:
            continue
    print(f"  ✓  Loaded {len(records)} eTransfer records.")
    return records


def match_etransfer(date, amount, history):
    abs_amt = abs(amount)
    has_real_date = hasattr(date, 'year')
    for rec in history:
        if abs(rec['amount'] - abs_amt) >= 0.005:
            continue
        if not has_real_date:
            return rec['name']
        if abs((date - rec['date']).days) <= 1:
            return rec['name']
    return None


# ══════════════════════════════════════════════════════════════════════════════
#  APPLY RULES
# ══════════════════════════════════════════════════════════════════════════════

def apply_rules(tx: dict, etransfer_history: list[dict]) -> dict:
    raw  = tx['full_raw']
    amt  = tx['amount']
    date = tx['date']

    name1, main, sub = match_transaction(raw)

    if name1 is None:
        # No merchant rule yet — show the raw text so it's easy to label.
        name1 = raw
        main  = "unknown"
        sub   = ""
        if ETRANSFER_RE.search(raw) and etransfer_history:
            person = match_etransfer(date, amt, etransfer_history)
            if person:
                name1 = person

    # Name2 = a FRESH copy of the raw bank text every run (NOT remembered). It's
    # your working column: check/fix Name1 against it, then reduce it down to the
    # LOCATION before exporting.
    name2 = raw

    return {**tx, 'name1': name1, 'name2': name2, 'main': main, 'sub': sub}


# ══════════════════════════════════════════════════════════════════════════════
#  EXCEL OUTPUT  — one clean, sortable sheet (a real Excel Table)
# ══════════════════════════════════════════════════════════════════════════════

HDR_FILL  = PatternFill("solid", fgColor="1F4E79")
SUM_HDR   = PatternFill("solid", fgColor="2E75B6")
SUM_TOT   = PatternFill("solid", fgColor="D6E4F0")
ALT_FILL  = PatternFill("solid", fgColor="EFF4FB")
_t = Side(border_style="thin", color="B0BEC5")
BORDER = Border(left=_t, right=_t, top=_t, bottom=_t)
AMT_FMT = '#,##0.00;[Red]-#,##0.00'

COLS      = ["Date", "Name1", "Name2", "Main", "Sub", "Amount", "Raw"]
WRAP_COLS = (3, 7)          # Name2 and Raw can be long — wrap them
CAPS      = {2: 30, 3: 32, 7: 55}   # cap long text columns; others auto-fit fully


def build_excel(rows: list[dict], out_path: Path):
    wb = Workbook()

    # ── Sheet 1: Transactions (a real Excel Table) ────────────────────
    ws = wb.active
    ws.title = "Transactions"
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A2"

    for ci, h in enumerate(COLS, 1):
        c = ws.cell(row=1, column=ci, value=h)
        c.font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 22

    for ri, tx in enumerate(rows, start=2):
        ws.cell(row=ri, column=1, value=str(tx['date']))
        ws.cell(row=ri, column=2, value=tx['name1'])
        ws.cell(row=ri, column=3, value=tx['name2'])
        ws.cell(row=ri, column=4, value=tx['main'])
        ws.cell(row=ri, column=5, value=tx['sub'])
        ac = ws.cell(row=ri, column=6, value=tx['amount'])
        ac.number_format = AMT_FMT
        ac.alignment = Alignment(horizontal="right")
        ws.cell(row=ri, column=7, value=tx['full_raw'])
        for c in range(1, 8):
            cell = ws.cell(row=ri, column=c)
            cell.font = Font(name="Arial", size=9)
            if c in WRAP_COLS:
                cell.alignment = Alignment(wrap_text=True, vertical="center")

    last = len(rows) + 1

    # Auto-fit each column to its contents (long text columns are capped + wrapped)
    for c in range(1, 8):
        maxlen = max((len(str(ws.cell(r, c).value)) for r in range(1, last + 1)
                      if ws.cell(r, c).value is not None), default=8)
        w = maxlen + 2
        if c in CAPS:
            w = min(w, CAPS[c])
        ws.column_dimensions[get_column_letter(c)].width = max(w, 8)

    if last >= 2:
        # Real Excel Table → whole-row sorting always holds, stripes auto-reband.
        table = Table(displayName="Transactions", ref=f"A1:G{last}")
        table.tableStyleInfo = TableStyleInfo(
            name="TableStyleMedium2", showRowStripes=True, showColumnStripes=False)
        ws.add_table(table)

        # Dropdown source lists live on a hidden sheet (no length limit, robust)
        mains, subs = ALL_CATEGORIES
        wsL = wb.create_sheet("Lists")
        wsL.sheet_state = "hidden"
        for i, v in enumerate(mains, 1):
            wsL.cell(row=i, column=1, value=v)
        for i, v in enumerate(subs, 1):
            wsL.cell(row=i, column=2, value=v)

        dv_main = DataValidation(type="list",
                                 formula1=f"Lists!$A$1:$A${len(mains)}",
                                 allow_blank=True, showDropDown=False)
        dv_main.sqref = f"D2:D{last}"
        ws.add_data_validation(dv_main)

        dv_sub = DataValidation(type="list",
                                formula1=f"Lists!$B$1:$B${len(subs)}",
                                allow_blank=True, showDropDown=False)
        dv_sub.sqref = f"E2:E{last}"
        ws.add_data_validation(dv_sub)

        # Conditional formatting — follows the data on sort (not baked to cells).
        # Unlabelled rows (Main = unknown) → orange across the whole row.
        ws.conditional_formatting.add(
            f"A2:G{last}",
            FormulaRule(formula=['$D2="unknown"'],
                        fill=PatternFill("solid", fgColor="FCE4D6"),
                        stopIfTrue=True))
        # Money in (positive Amount, column F) → soft green.
        ws.conditional_formatting.add(
            f"A2:G{last}",
            FormulaRule(formula=['$F2>0'],
                        fill=PatternFill("solid", fgColor="E2EFDA")))

    # ── Sheet 2: Main Summary ─────────────────────────────────────────
    ws2 = wb.create_sheet("Main Summary")
    ws2.sheet_view.showGridLines = False
    cat_totals = defaultdict(float)
    for tx in rows:
        cat_totals[tx['main']] += tx['amount']
    income_items = sorted([(k, v) for k, v in cat_totals.items() if v > 0], key=lambda x: -x[1])
    spend_items  = sorted([(k, v) for k, v in cat_totals.items() if v <= 0], key=lambda x:  x[1])
    sorted_cats  = income_items + spend_items
    total_in  = sum(v for v in cat_totals.values() if v > 0)
    total_out = sum(v for v in cat_totals.values() if v < 0)

    ws2.column_dimensions["A"].width = 20
    ws2.column_dimensions["B"].width = 15
    for ci, h in enumerate(["Main", "Total ($)"], 1):
        c = ws2.cell(row=1, column=ci, value=h)
        c.font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
        c.fill = SUM_HDR
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = BORDER
    ws2.row_dimensions[1].height = 24
    for ri, (cat, total) in enumerate(sorted_cats, start=2):
        ws2.cell(row=ri, column=1, value=cat).font = Font(name="Arial", size=9)
        ac = ws2.cell(row=ri, column=2, value=round(total, 2))
        ac.number_format = AMT_FMT
        ac.font = Font(name="Arial", size=9, bold=True,
                       color="2E7D32" if total > 0 else "000000")
        for c in range(1, 3):
            cell = ws2.cell(row=ri, column=c)
            cell.border = BORDER
            if ri % 2 == 0:
                cell.fill = ALT_FILL
    for off, (lbl, val) in enumerate([("Total Income", total_in),
                                      ("Total Spending", total_out),
                                      ("Net", total_in + total_out)]):
        r = len(sorted_cats) + 2 + off
        ws2.cell(row=r, column=1, value=lbl).font = Font(name="Arial", bold=True, size=9)
        vc = ws2.cell(row=r, column=2, value=round(val, 2))
        vc.number_format = AMT_FMT
        vc.font = Font(name="Arial", bold=True, size=9)
        for c in range(1, 3):
            ws2.cell(row=r, column=c).fill = SUM_TOT
            ws2.cell(row=r, column=c).border = BORDER

    # ── Sheet 3: How To Use (kept OFF the data sheet so sorting can't grab it)
    ws3 = wb.create_sheet("How To Use")
    ws3.sheet_view.showGridLines = False
    ws3.column_dimensions["A"].width = 100
    tips = [
        "HOW THIS FILE WORKS",
        "",
        "Columns:  Date | Name1 | Name2 | Main | Sub | Amount | Raw",
        "",
        "• Name1  — the clean merchant name. Remembered: label it once and every",
        "           matching transaction, this year and every future year, gets it.",
        "• Name2  — a FRESH copy of the raw text every run (NOT remembered). Use it",
        "           to check/fix Name1, then reduce it down to the LOCATION before export.",
        "• Main   — primary category (dropdown). Remembered.",
        "• Sub    — independent breakdown (dropdown). Remembered.",
        "• Amount — read from the statement each run.",
        "• Raw    — the untouched bank string. Never changes — your safety copy.",
        "",
        "• Orange row = not labelled yet (Main is 'unknown'). Type Name1/Main/Sub on",
        "  the row, save, close, and re-run — it's learned automatically and stays.",
        "• Green row = money in (a deposit / positive amount).",
        "• It's a real Excel table, so sort/filter any column and whole rows hold.",
        "",
        "Your memory lives in merchant_list.txt and carries across every year. You",
        "normally never open it. To send the finished list to the budget dashboard,",
        "run export_to_dashboard.bat.",
    ]
    for ri, line in enumerate(tips, 1):
        c = ws3.cell(row=ri, column=1, value=line)
        c.font = Font(name="Arial", size=10, bold=(ri == 1),
                      color="1F4E79" if ri == 1 else "000000")

    wb.save(str(out_path))


def export_categories_for_dashboard(folder: Path):
    """merchant_reference.md — merchants grouped by Main with their Sub, a
    readable reference you can organize before passing names along."""
    out = folder / "merchant_reference.md"
    by_main = {}
    for rule in _RULES:
        by_main.setdefault(rule["main"], []).append(rule)

    lines = ["# Merchant Reference", "",
             "_Generated from merchant_list.txt. Main = primary sort, Sub = breakdown._", ""]
    order = [c for c in MAIN_CATEGORIES if c in by_main] + \
            [c for c in by_main if c not in MAIN_CATEGORIES and c != "unknown"]
    for main in order:
        lines.append(f"## {main}")
        for rule in sorted(by_main[main], key=lambda r: r["name1"].lower()):
            sub = rule["sub"] if rule["sub"] else "—"
            lines.append(f"- **{rule['name1']}** — {sub}")
        lines.append("")

    out.write_text("\n".join(lines), encoding="utf-8")
    print(f"  ·  merchant_reference.md written ({len(_RULES)} merchants)")
    return out


def export_to_dashboard(folder: Path, review_path: Path):
    """Read the finished review sheet and write Dashboard_Export.xlsx shaped for
    DalaDash: A=Date, B=Main(category), C=Name1(description), D=Amount, E=Sub,
    F=Location(Name2), with data starting on row 3 to match DalaDash's layout."""
    if not review_path.exists():
        print(f"  ❌  No review file found at {review_path.name}. Run the parser first.")
        return None
    from openpyxl import load_workbook
    wb_in = load_workbook(review_path, data_only=True)
    ws_in = wb_in["Transactions"] if "Transactions" in wb_in.sheetnames else wb_in.active
    hdr = {str(ws_in.cell(1, c).value).strip().lower(): c
           for c in range(1, ws_in.max_column + 1)}
    cDate = hdr.get("date"); cN1 = hdr.get("name1"); cN2 = hdr.get("name2")
    cMain = hdr.get("main"); cSub = hdr.get("sub");  cAmt = hdr.get("amount")

    wb = Workbook()
    ws = wb.active
    ws.title = "Statements"
    headers = ["Date", "Main", "Description", "Amount", "Sub", "Location"]
    for ci, h in enumerate(headers, 1):                       # header on row 2
        c = ws.cell(row=2, column=ci, value=h)
        c.font = Font(name="Arial", bold=True)
    out_r = 3                                                 # data starts row 3
    for r in range(2, ws_in.max_row + 1):
        date = ws_in.cell(r, cDate).value if cDate else None
        if date is None:
            continue
        ws.cell(row=out_r, column=1, value=ws_in.cell(r, cDate).value)
        ws.cell(row=out_r, column=2, value=ws_in.cell(r, cMain).value if cMain else "")
        ws.cell(row=out_r, column=3, value=ws_in.cell(r, cN1).value if cN1 else "")   # Name1
        ac = ws.cell(row=out_r, column=4, value=ws_in.cell(r, cAmt).value if cAmt else 0)
        ac.number_format = AMT_FMT
        ws.cell(row=out_r, column=5, value=ws_in.cell(r, cSub).value if cSub else "")
        ws.cell(row=out_r, column=6, value=ws_in.cell(r, cN2).value if cN2 else "")    # Name2 = Location
        out_r += 1
    for col, w in zip("ABCDEF", [13, 12, 32, 12, 12, 22]):
        ws.column_dimensions[col].width = w

    out = folder / "Dashboard_Export.xlsx"
    wb.save(str(out))
    print(f"  📤  Dashboard_Export.xlsx written ({out_r - 3} rows).")
    return out


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════

def pick_folder_dialog(title="Select folder"):
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        chosen = filedialog.askdirectory(title=title)
        root.destroy()
        return Path(chosen) if chosen else None
    except Exception:
        return None


def clean_path_input(raw: str) -> Path:
    s = raw.strip()
    s = re.sub(r"^&\s*", "", s)
    s = s.strip()
    s = re.sub(r"^['\"]", "", s)
    s = re.sub(r"['\"]$", "", s)
    return Path(s.strip())


def main():
    ap = argparse.ArgumentParser(description="PDF2Sheets v3")
    ap.add_argument('--folder',    type=str)
    ap.add_argument('--etransfer', type=str)
    ap.add_argument('--output',    type=str)
    ap.add_argument('--export', action='store_true',
                    help="Export the finished review sheet to the dashboard and exit.")
    args = ap.parse_args()

    print("\n╔══════════════════════════════════════════════╗")
    print("║   PDF2Sheets  v3.0       ║")
    print("╚══════════════════════════════════════════════╝\n")

    # folder
    if args.folder:
        folder = clean_path_input(args.folder)
    else:
        print("📂  Opening folder picker…")
        folder = pick_folder_dialog("Select the folder with your PDF statements")
        if not folder:
            folder = clean_path_input(input("    Folder path: "))
    if not folder or not folder.exists() or not folder.is_dir():
        print(f"\n❌  Folder not found: {folder}")
        folder = clean_path_input(input("    Folder path: "))
        if not folder.exists() or not folder.is_dir():
            print("\n❌  Still can't find it. Exiting.")
            sys.exit(1)

    review_path = Path(args.output) if args.output else folder / "PDF2Sheets_Review.xlsx"

    # ── EXPORT MODE: read the finished review sheet, write the dashboard file ──
    if args.export:
        print("📤  Exporting finished list to the dashboard...\n")
        # also fold in any last labels before exporting
        learn_from_review(review_path)
        export_to_dashboard(folder, review_path)
        print("\n✅  Done. Drop Dashboard_Export.xlsx into your DalaDash statements folder.\n")
        return

    # eTransfer history (optional)
    etransfer_history = []
    if args.etransfer and Path(args.etransfer).exists():
        print(f"\n📋  eTransfer history: {Path(args.etransfer).name}")
        etransfer_history = load_etransfer_history(Path(args.etransfer))
    elif not args.etransfer:
        for candidate in folder.glob('*'):
            if ('etransfer' in candidate.stem.lower() or 'e-transfer' in candidate.stem.lower()) \
                    and candidate.suffix.lower() in ('.csv', '.xlsx', '.xls'):
                print(f"\n📋  Auto-detected eTransfer history: {candidate.name}")
                etransfer_history = load_etransfer_history(candidate)
                break

    # PDFs — recurse into year folders, sort oldest first by year then month
    def _sort_key(f):
        y, mo = year_month_from_path(f)
        return (y or 0, mo or 0, f.name)
    pdfs = sorted(folder.rglob('*.pdf'), key=_sort_key)
    if not pdfs:
        print(f"\n❌  No PDF files found in: {folder}")
        print("    (Searched subfolders too — check the path points at your statements.)")
        sys.exit(1)
    print(f"\n📄  Found {len(pdfs)} PDF(s) under {folder.name}/\n")

    # Learn any labels you typed in the review sheet last time (before rebuild)
    learned = learn_from_review(review_path)
    if learned:
        print(f"  ✓  Learned {learned} merchant label(s) from your last review sheet.")

    all_tx = []
    for pdf_path in pdfs:
        print(f"  ⏳  {pdf_path.name} ...", end=' ')
        try:
            txs = parse_pdf(pdf_path)
            all_tx.extend(apply_rules(tx, etransfer_history) for tx in txs)
            print(f"✓  {len(txs)} transactions")
        except Exception as e:
            print(f"❌  Error: {e}")

    if not all_tx:
        print("\n❌  No transactions extracted. Check the PDF format.")
        sys.exit(1)

    print("\n📊  Building review file...")
    build_excel(all_tx, review_path)
    export_categories_for_dashboard(folder)

    n_unknown = sum(1 for t in all_tx if t['main'] == 'unknown')
    total_in  = sum(t['amount'] for t in all_tx if t['amount'] > 0)
    total_out = sum(t['amount'] for t in all_tx if t['amount'] < 0)
    print(f"\n✅  Done!  →  {review_path.name}")
    print(f"    Statements processed : {len(pdfs)}")
    print(f"    Total transactions   : {len(all_tx)}")
    print(f"    Total income         : ${total_in:,.2f}")
    print(f"    Total spending       : ${total_out:,.2f}")
    print(f"    Net                  : ${total_in + total_out:,.2f}")
    if n_unknown:
        print(f"\n    ⚠  {n_unknown} transaction(s) not labelled yet (orange rows).")
        print(f"       Open {review_path.name}, type Name1/Main/Sub on those rows,")
        print(f"       save, and re-run — your labels are learned and carried forward.")
    print(f"\n    When the list is ready, run export_to_dashboard.bat to send it on.")
    print()


if __name__ == "__main__":
    main()
