# PDF2Sheets

A simple tool that pulls every transaction out of your bank PDF statements
and drops them into one tidy Excel review sheet. You label each merchant once;
it remembers the label forever — across this year's statements and every future
year. When you're done labelling, one click exports the cleaned list to a
dashboard-ready file.

> Note: the PDF parsing logic was built around Scotiabank statement layouts.
> Other banks' formats may or may not parse cleanly out of the box.

**No paths are hard-coded.** The first time you run it, a folder picker pops up
and asks where your statements live. Your labels live in a `merchant_list.txt`
that the script creates next to itself.

---

## What's in the folder

- `pdf2sheets.py` — the script that does the work
- `run_parser.bat` — double-click to process your statements
- `export_to_dashboard.bat` — double-click when you're done labelling
- `README.md` — this file

(`merchant_list.txt` gets created automatically on first run.)

---

## One-time setup

1. Install Python 3 from https://www.python.org (during install, tick **Add
   Python to PATH**).
2. Open a Command Prompt and run:
   ```
   pip install pdfplumber pandas openpyxl
   ```

That's it.

---

## How to use it

1. Drop this whole folder anywhere on your PC.
2. Put your PDF statements anywhere you like — one folder, with subfolders by
   year if you want. They can sit somewhere completely separate from these
   scripts.
3. **Double-click `run_parser.bat`.** A folder picker will open — point it at
   the folder holding your statements.
4. When it finishes, open `PDF2Sheets_Review.xlsx` (created in your statements
   folder). Fill in the orange/unlabelled rows: type a clean name in **Name1**,
   pick a **Main** and **Sub** category from the dropdowns. Save and close.
5. Re-run `run_parser.bat` any time you add new statements — your labels are
   remembered automatically.
6. When the list is clean and you're ready to push it to your dashboard, polish
   the **Name2** column down to just the location, then **double-click
   `export_to_dashboard.bat`**. It writes `Dashboard_Export.xlsx` in the same
   folder.

---

## The review sheet columns

| Column | What it is | Remembered? |
|---|---|---|
| Date | Transaction date | — |
| Name1 | Clean merchant name you type | ✅ yes |
| Name2 | Raw text — trim down to a location before export | ❌ fresh each run |
| Main | Primary category (dropdown) | ✅ yes |
| Sub | Independent breakdown (dropdown) | ✅ yes |
| Amount | From the statement | — |
| Raw | Untouched bank string | — |

---

## Notes

- The script only reads your PDFs; it never edits them.
- All output files (`PDF2Sheets_Review.xlsx`, `Dashboard_Export.xlsx`,
  `merchant_list.txt`, `merchant_reference.md`) are written into the folder
  you picked, not into the script folder.
- If the bat files flash and close instantly, open Command Prompt, `cd` into
  this folder, and run `python pdf2sheets.py` directly — you'll see the
  error message.
