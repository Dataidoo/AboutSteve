"""
daladash.py
-----------
Run with:  python daladash.py
Requires:  pip install pywebview openpyxl

To build a standalone .exe (no Python needed to run), see build_exe.bat
"""

import sys
import webview
import threading
import json
import os
import glob
from datetime import datetime
from openpyxl import load_workbook

# ── PATHS (work both as script and as a PyInstaller .exe) ─────────
def app_dir():
    """Folder the program lives in — next to the .exe when frozen."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def bundled(name):
    """Path to a file bundled inside the .exe (or local when running as script)."""
    if getattr(sys, "frozen", False):
        return os.path.join(sys._MEIPASS, name)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), name)

# ── CONFIG FILE ───────────────────────────────────────────────────
CONFIG_PATH = os.path.join(app_dir(), "daladash_config.json")

DEFAULT_CONFIG = {
    "folders": [
        {
            "id":       "current",
            "label":    "Current",
            "path":     r"C:\Users\my pc\Desktop\STEVE_STUFF\BANK_FILES\CURRENT",
            "type":     "current",
            "mapping":  {"date": "A", "description": "B", "name2": "C", "category": "D", "sub": "E", "amount": "F"},
            "start_row": 2
        },
        {
            "id":       "statements",
            "label":    "Statements",
            "path":     r"C:\Users\my pc\Desktop\STEVE_STUFF\BANK_FILES\OLD_STATEMENTS",
            "type":     "yearly",
            "mapping":  {"date": "A", "description": "B", "name2": "C", "category": "D", "sub": "E", "amount": "F"},
            "start_row": 2
        },
        {
            "id":       "taxes",
            "label":    "Taxes",
            "path":     r"C:\Users\my pc\Desktop\STEVE_STUFF\BANK_FILES\TAXES",
            "type":     "flat",
            "mapping":  {"date": "A", "description": "B", "name2": "C", "category": "D", "sub": "E", "amount": "F"},
            "start_row": 2
        },
        {
            "id":       "savings",
            "label":    "Savings",
            "path":     r"C:\Users\my pc\Desktop\STEVE_STUFF\BANK_FILES\SAVINGS",
            "type":     "flat",
            "mapping":  {"date": "A", "description": "B", "name2": "C", "category": "D", "sub": "E", "amount": "F"},
            "start_row": 2
        },
        {
            "id":       "debts",
            "label":    "Debts",
            "path":     r"C:\Users\my pc\Desktop\STEVE_STUFF\BANK_FILES\DEBTS",
            "type":     "flat",
            "mapping":  {"date": "A", "description": "B", "name2": "C", "category": "D", "sub": "E", "amount": "F"},
            "start_row": 2
        }
    ],
    "taxes": {}
}

def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r") as f:
            return json.load(f)
    return DEFAULT_CONFIG

def save_config(cfg):
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)

# ── EXCEL READER ──────────────────────────────────────────────────
def col_letter_to_index(letter):
    letter = letter.upper().strip()
    result = 0
    for c in letter:
        result = result * 26 + (ord(c) - ord('A') + 1)
    return result

def read_xlsx(path, mapping, start_row):
    """Read an xlsx file using column mapping. Returns list of row dicts."""
    rows = []
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb.active
        col_map = {field: col_letter_to_index(col) for field, col in mapping.items() if col}

        for r in ws.iter_rows(min_row=start_row, values_only=True):
            if all(v is None for v in r):
                continue
            row = {"_source": os.path.basename(path)}
            for field, cidx in col_map.items():
                val = r[cidx - 1] if cidx - 1 < len(r) else None
                if isinstance(val, datetime):
                    val = val.strftime("%m/%d/%Y")
                elif val is not None:
                    val = str(val).strip()
                row[field] = val
            # only include rows that have at least one mapped value
            if any(row.get(f) for f in col_map):
                rows.append(row)
        wb.close()
    except Exception as e:
        print(f"  Error reading {path}: {e}")
    return rows

def read_xlsx_headers(path):
    """Read column headers from row 1 for mapping setup."""
    headers = {}
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb.active
        for row in ws.iter_rows(min_row=1, max_row=1, values_only=True):
            for i, val in enumerate(row):
                if val:
                    col_letter = ""
                    n = i + 1
                    while n:
                        n, rem = divmod(n - 1, 26)
                        col_letter = chr(65 + rem) + col_letter
                    headers[col_letter] = str(val)
            break
        wb.close()
    except Exception as e:
        print(f"  Error reading headers {path}: {e}")
    return headers

def scan_folder(folder_cfg):
    """Scan a folder config and return all rows with metadata."""
    ftype   = folder_cfg.get("type", "flat")
    path    = folder_cfg["path"]
    mapping = folder_cfg.get("mapping", {})
    start   = folder_cfg.get("start_row", 2)
    label   = folder_cfg["label"]
    results = []

    if not os.path.exists(path):
        return results

    if ftype == "yearly":
        # walk year/month structure
        for year_dir in sorted(glob.glob(os.path.join(path, "*"))):
            if not os.path.isdir(year_dir):
                continue
            year = os.path.basename(year_dir)
            for xlsx in sorted(glob.glob(os.path.join(year_dir, "*.xlsx"))):
                month = os.path.splitext(os.path.basename(xlsx))[0]
                rows  = read_xlsx(xlsx, mapping, start)
                for r in rows:
                    r["_folder"] = label
                    r["_year"]   = year
                    r["_month"]  = month
                    r["_file"]   = xlsx
                results.extend(rows)
    else:
        # flat folder — one or more xlsx files
        for xlsx in sorted(glob.glob(os.path.join(path, "*.xlsx"))):
            rows = read_xlsx(xlsx, mapping, start)
            for r in rows:
                r["_folder"] = label
                r["_year"]   = ""
                r["_month"]  = ""
                r["_file"]   = xlsx
            results.extend(rows)

    return results

# ── API EXPOSED TO FRONTEND ───────────────────────────────────────
class Api:
    def __init__(self):
        self._config = load_config()
        self._cache  = {}   # folder_id -> rows

    def get_config(self):
        return json.dumps(self._config)

    def save_config(self, cfg_json):
        self._config = json.loads(cfg_json)
        save_config(self._config)
        self._cache = {}
        return "ok"

    def get_all_data(self):
        """Load all folders and return combined rows."""
        all_rows = []
        for folder in self._config["folders"]:
            fid = folder["id"]
            if fid not in self._cache:
                self._cache[fid] = scan_folder(folder)
            all_rows.extend(self._cache[fid])
        return json.dumps(all_rows)

    def get_folder_data(self, folder_id):
        folder = next((f for f in self._config["folders"] if f["id"] == folder_id), None)
        if not folder:
            return json.dumps([])
        if folder_id not in self._cache:
            self._cache[folder_id] = scan_folder(folder)
        return json.dumps(self._cache[folder_id])

    def refresh(self):
        self._cache = {}
        return "ok"

    def get_file_headers(self, path):
        return json.dumps(read_xlsx_headers(path))

    def get_taxes(self):
        return json.dumps(self._config.get("taxes", {}))

    def set_tax(self, year, filed):
        if "taxes" not in self._config:
            self._config["taxes"] = {}
        self._config["taxes"][str(year)] = bool(filed)
        save_config(self._config)
        return "ok"

    def open_file(self, path):
        """Open a file in its default application (LibreOffice)."""
        import subprocess
        try:
            os.startfile(path)
        except Exception:
            subprocess.Popen(["xdg-open", path])
        return "ok"

# ── LAUNCH ────────────────────────────────────────────────────────
if __name__ == "__main__":
    api = Api()
    html = bundled("daladash.html")
    window = webview.create_window(
        title="DalaDash",
        url=html,
        js_api=api,
        width=1400,
        height=900,
        min_size=(1000, 600),
        background_color="#232629",
    )
    webview.start(debug=False)
