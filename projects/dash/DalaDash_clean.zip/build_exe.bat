@echo off
REM ============================================================
REM  Build DalaDash into a single Windows .exe + desktop shortcut.
REM
REM  Run this from the DALADASH folder (where daladash.py lives).
REM
REM  Folder must contain:
REM    daladash.py
REM    daladash.html
REM    chart.umd.min.js
REM    DALADATA.ico
REM    assets\        (icons + bg_logo.png)
REM
REM  After running:
REM    dist\DalaDash.exe                  the app
REM    %USERPROFILE%\Desktop\DalaDash.lnk a desktop shortcut
REM ============================================================
setlocal

REM ---- pre-flight: warn before wasting a 60-second build ----
set MISSING=
if not exist "daladash.py"        set MISSING=%MISSING% daladash.py
if not exist "daladash.html"      set MISSING=%MISSING% daladash.html
if not exist "chart.umd.min.js"   set MISSING=%MISSING% chart.umd.min.js
if not exist "DALADATA.ico"       set MISSING=%MISSING% DALADATA.ico
if not exist "assets"             set MISSING=%MISSING% assets\

if not "%MISSING%"=="" (
  echo.
  echo  Missing required files in this folder:
  echo    %MISSING%
  echo  Put them here, then run this again.
  echo.
  pause
  exit /b 1
)

echo Installing build tools...
py -m pip install --upgrade pyinstaller pywebview openpyxl
if errorlevel 1 (
  echo.
  echo  pip install failed. Is Python installed and on PATH?
  pause
  exit /b 1
)

echo.
echo Building DalaDash.exe ...

py -m PyInstaller ^
  --noconfirm ^
  --onefile ^
  --windowed ^
  --name DalaDash ^
  --icon "DALADATA.ico" ^
  --add-data "daladash.html;." ^
  --add-data "chart.umd.min.js;." ^
  --add-data "assets;assets" ^
  daladash.py

if not exist "dist\DalaDash.exe" (
  echo.
  echo  Build failed. dist\DalaDash.exe was not created.
  echo  Scroll up for PyInstaller errors.
  pause
  exit /b 1
)

echo.
echo Creating desktop shortcut...

REM ---- PowerShell makes a clean .lnk that says "DalaDash" with no .exe ----
REM    Working directory is set to dist\ so the config file lands next to the .exe.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$exe = (Resolve-Path '.\dist\DalaDash.exe').Path;" ^
  "$ico = (Resolve-Path '.\DALADATA.ico').Path;" ^
  "$work = (Resolve-Path '.\dist').Path;" ^
  "$desktop = [Environment]::GetFolderPath('Desktop');" ^
  "$lnk = Join-Path $desktop 'DalaDash.lnk';" ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "$s = $ws.CreateShortcut($lnk);" ^
  "$s.TargetPath = $exe;" ^
  "$s.WorkingDirectory = $work;" ^
  "$s.IconLocation = $ico;" ^
  "$s.Description = 'DalaDash';" ^
  "$s.Save();" ^
  "Write-Host '  Shortcut created at' $lnk"

echo.
echo ============================================================
echo  Done.
echo    App:       dist\DalaDash.exe
echo    Shortcut:  %USERPROFILE%\Desktop\DalaDash.lnk
echo.
echo  Double-click the shortcut to run. No Python needed after this.
echo.
echo  Note: daladash_config.json (your folders + tax checks)
echo  will be created next to DalaDash.exe on first run.
echo ============================================================
pause
endlocal
